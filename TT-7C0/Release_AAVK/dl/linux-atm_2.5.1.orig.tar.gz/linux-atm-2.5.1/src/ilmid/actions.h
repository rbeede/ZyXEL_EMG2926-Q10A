#ifndef __ACTIONS_H
#define __ACTIONS_H

#include "ilmid.h"

void action_A1( int fd, Msgs *msgs );
void action_A2( int fd, Msgs *msgs );
void action_A3( int fd, Msgs *msgs );
void action_A4( int fd, Msgs *msgs );
void action_A5( int fd, Msgs *msgs );
void action_A6( int fd, Msgs *msgs );
void action_A7( int fd, Msgs *msgs );
void action_A8( int fd, Msgs *msgs );
void action_A9( int fd, Msgs *msgs );
void action_A10( int fd, Msgs *msgs );
void action_A11( int fd, Msgs *msgs );
void action_A12( int fd, Msgs *msgs );
void action_A13( int fd, Msgs *msgs );
void action_A14( int fd, Msgs *msgs );
void action_A15( int fd, Msgs *msgs );
void action_get_sysgroup( int fd, Msgs *msgs );

#endif

